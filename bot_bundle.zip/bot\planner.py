from bot.reasons import SkipReason, AttemptReport
from typing import List, Tuple
import datetime

def plan_attempts(*, origin, dests, config, state_store) -> Tuple[list, list]:
    """
    Retorna:
      - attempts: lista de dicts (origin, dest, date, ceiling, url, ...)
      - reports: lista de AttemptReport (SKIP)
    """
    attempts = []
    reports = []
    for dest in dests:
        # Exemplo: gerar datas elegíveis (7 dias a partir de hoje)
        today = datetime.date.today()
        eligible_dates = [today + datetime.timedelta(days=i) for i in range(config.get('date_window_days', 7))]
        # Filtros customizáveis
        if config.get('weekdays_only'):
            eligible_dates = [d for d in eligible_dates if d.weekday() < 5]
        if not eligible_dates:
            reports.append(AttemptReport(
                origin=origin,
                dest=dest,
                date=None,
                phase="SKIP",
                reason=SkipReason.NO_ELIGIBLE_DATES.name,
                details={"date_window_days": config.get('date_window_days', 7), "weekdays_only": config.get('weekdays_only', False)}
            ))
            continue
        for date in eligible_dates:
            date_str = date.isoformat()
            cooldown_key = f"{origin}|{dest}|{date_str}"
            if hasattr(state_store, "is_in_cooldown") and state_store.is_in_cooldown(cooldown_key):
                reports.append(AttemptReport(
                    origin=origin,
                    dest=dest,
                    date=date_str,
                    phase="SKIP",
                    reason=SkipReason.COOLDOWN_ACTIVE.name,
                    details={"cooldown_key": cooldown_key}
                ))
                continue
            # Monta attempt
            attempt = {
                "origin": origin,
                "dest": dest,
                "date": date_str,
                "ceiling": config.get('PRICE_CEILINGS_OW', {}).get(dest, config.get('DEFAULT_PRICE_CEILING_OW', 9999)),
                "url": config.get('build_kiwi_url_ow')(origin, dest, date_str, sort_by_price=True) if config.get('build_kiwi_url_ow') else None
            }
            attempts.append(attempt)
    return attempts, reports
