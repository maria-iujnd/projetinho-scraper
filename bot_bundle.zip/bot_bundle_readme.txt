Este arquivo ZIP contém todos os arquivos do bot de passagens, incluindo código-fonte, módulos, scripts de deploy, configurações e utilitários.

- Data de exportação: 2026-01-30
- Host: exportado localmente
- Instruções: Extraia o ZIP e revise os arquivos conforme necessário. Não inclui dados sensíveis nem o banco de dados completo.

Se precisar de instruções para rodar, consulte README.md ou README_DEPLOY.md.
