import os
import sys
import time
import psutil
import shutil

def log(level, msg):
    ts = time.strftime("%H:%M:%S")
    print(f"[{ts}] [{level}] {msg}")

def find_chrome_processes_with_profile(profile_dir):
    """
    Retorna lista de processos Chrome usando o profile_dir.
    """
    procs = []
    for p in psutil.process_iter(['pid', 'name', 'cmdline']):
        try:
            if not p.info['name'] or 'chrome' not in p.info['name'].lower():
                continue
            cmd = ' '.join(p.info['cmdline'])
            if profile_dir.replace('/', '\\') in cmd or profile_dir in cmd:
                procs.append(p)
        except Exception:
            continue
    return procs

def cleanup_chrome_profile_locks(profile_dir):
    """
    Remove arquivos de lock temporários do Chrome profile.
    """
    lockfiles = [
        'SingletonLock', 'SingletonSocket', 'SingletonCookie', 'lockfile'
    ]
    for fname in lockfiles:
        fpath = os.path.join(profile_dir, fname)
        if os.path.exists(fpath):
            try:
                os.remove(fpath)
                log('INFO', f"Removido lock temporário: {fpath}")
            except Exception as e:
                log('WARN', f"Não foi possível remover lock {fpath}: {e}")

def ensure_chrome_profile_free(profile_dir, max_attempts=3, wait_sec=5):
    """
    Garante que o profile do Chrome está livre para uso pelo Selenium.
    Tenta encerrar processos antigos e limpar locks, com retentativas.
    """
    for attempt in range(1, max_attempts+1):
        procs = find_chrome_processes_with_profile(profile_dir)
        if not procs:
            cleanup_chrome_profile_locks(profile_dir)
            log('INFO', f"Profile livre para uso: {profile_dir}")
            return True
        log('WARN', f"Chrome já em uso com profile {profile_dir} (tentativa {attempt}/{max_attempts})")
        for p in procs:
            try:
                log('WARN', f"Encerrando Chrome PID={p.pid} CMD={' '.join(p.info['cmdline'])}")
                p.terminate()
            except Exception as e:
                log('ERROR', f"Falha ao encerrar Chrome PID={p.pid}: {e}")
        gone, alive = psutil.wait_procs(procs, timeout=10)
        if alive:
            for p in alive:
                try:
                    log('ERROR', f"Chrome ainda vivo: PID={p.pid} CMD={' '.join(p.info['cmdline']) if p.info.get('cmdline') else 'N/A'}")
                except Exception:
                    log('ERROR', f"Chrome ainda vivo: PID={p.pid} (erro ao obter cmdline)")
            log('ERROR', f"Ainda há Chrome(s) vivos após tentativa de kill: {[p.pid for p in alive]}")
        cleanup_chrome_profile_locks(profile_dir)
        if attempt < max_attempts:
            log('INFO', f"Aguardando {wait_sec}s antes de nova tentativa...")
            time.sleep(wait_sec)
    # Log final detalhado dos processos que impediram a liberação
    procs = find_chrome_processes_with_profile(profile_dir)
    if procs:
        log('ERROR', f"Processos impedindo liberação do profile {profile_dir}:")
        for p in procs:
            try:
                log('ERROR', f"PID={p.pid} CMD={' '.join(p.info['cmdline']) if p.info.get('cmdline') else 'N/A'}")
            except Exception:
                log('ERROR', f"PID={p.pid} (erro ao obter cmdline)")
    log('ERROR', f"Não foi possível liberar o profile do Chrome após {max_attempts} tentativas!")
    log('ERROR', f"Feche manualmente todos os Chromes que usam o profile ou reinicie o computador.")
    return False
