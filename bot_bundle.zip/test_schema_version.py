#!/usr/bin/env python3
"""Test schema versioning."""
import os
import sqlite3
import state_store

# Clean up
db_path = "test_schema.db"
if os.path.exists(db_path):
    os.remove(db_path)

print("=== Test 1: Create new DB ===")
state_store.setup_database(db_path)
print("✓ DB created")

# Check version
conn = sqlite3.connect(db_path)
cursor = conn.execute("SELECT version FROM schema_meta")
row = cursor.fetchone()
print(f"Schema version in DB: {row[0]}")
assert row[0] == 1, "Should be version 1"

# Check tables
cursor = conn.execute("SELECT name FROM sqlite_master WHERE type='table'")
tables = [r[0] for r in cursor.fetchall()]
print(f"Tables: {sorted(tables)}")
assert 'schema_meta' in tables, "schema_meta missing"
assert 'route_date_state' in tables, "route_date_state missing"
assert 'announcements' in tables, "announcements missing"
assert 'rt_price_history' in tables, "rt_price_history missing"
conn.close()

print("\n=== Test 2: Re-init same DB (should not re-create) ===")
state_store.setup_database(db_path)
print("✓ DB re-opened")

conn = sqlite3.connect(db_path)
cursor = conn.execute("SELECT COUNT(*) FROM schema_meta")
count = cursor.fetchone()[0]
print(f"Rows in schema_meta: {count}")
assert count == 1, "Should have 1 row"
conn.close()

print("\n=== Test 3: Check function consistency ===")
# Test that mark_announced works with new schema
state_store.mark_announced("test_hash_123", db_path)
print("✓ mark_announced() works")

# Check it was inserted
conn = sqlite3.connect(db_path)
cursor = conn.execute("SELECT trip_type FROM announcements WHERE offer_hash='test_hash_123'")
row = cursor.fetchone()
assert row is not None, "offer_hash not found"
assert row[0] == "OW", f"trip_type should be OW, got {row[0]}"
conn.close()

print("\n✅ All schema versioning tests passed!")

# Cleanup
os.remove(db_path)
if os.path.exists(db_path + "-wal"):
    os.remove(db_path + "-wal")
if os.path.exists(db_path + "-shm"):
    os.remove(db_path + "-shm")
