import os
import re
import json
import shutil
import zipfile
import socket
import glob
from datetime import datetime, timedelta

def sanitize_text(text: str) -> str:
    """
    Mascarar telefones, emails, tokens, keys, senhas, urls sensíveis.
    """
    patterns = [
        (r'\b\d{10,15}\b', '***'),  # telefones
        (r'[\w\.-]+@[\w\.-]+', '***'),  # emails
        (r'(token|pass|key|secret|senha|api[_-]?key)[^=\n]*=[^\n]+', r'\1=***'),
        (r'(Bearer|Token|Basic) [A-Za-z0-9\._\-]+', r'\1 ***'),
        (r'(https?://[^\s]+[?&](token|key|pass|senha)=[^&\s]+)', r'\1=***'),
    ]
    for pat, repl in patterns:
        text = re.sub(pat, repl, text, flags=re.IGNORECASE)
    return text

def tail_lines(path, n=2000):
    try:
        with open(path, 'r', encoding='utf-8', errors='ignore') as f:
            return ''.join(f.readlines()[-n:])
    except Exception:
        return ''

def collect_debug_bundle(*, since_minutes: int, out_dir: str, include_screenshots: bool = False) -> str:
    ts = datetime.now().strftime('%Y%m%d_%H%M%S')
    bundle_dir = os.path.join(out_dir, f'debug_{ts}')
    os.makedirs(bundle_dir, exist_ok=True)
    logs_dir = os.path.join(bundle_dir, 'logs')
    os.makedirs(logs_dir, exist_ok=True)
    # 1. Logs
    log_files = [
        os.environ.get('LOG_FILE', '/var/log/kiwi_bot.log'),
        '/var/log/kiwi_bot/service.out.log',
        '/var/log/kiwi_bot/service.err.log',
    ]
    for log in log_files:
        if os.path.exists(log):
            content = tail_lines(log, 2000)
            with open(os.path.join(logs_dir, os.path.basename(log)), 'w', encoding='utf-8') as f:
                f.write(sanitize_text(content))
    # 2. Heartbeat
    for hb in ['bot/heartbeat.json', 'heartbeat.json']:
        if os.path.exists(hb):
            shutil.copy2(hb, os.path.join(bundle_dir, 'heartbeat.json'))
            break
    # 3. Runtime state
    for rs in ['bot/runtime_state.json', 'runtime_state.json']:
        if os.path.exists(rs):
            shutil.copy2(rs, os.path.join(bundle_dir, 'runtime_state.json'))
            break
    # 4. DB summary seguro
    db_summary = {}
    try:
        from bot.runtime_state import load_runtime_state
        state = load_runtime_state()
        db_summary['counts'] = state.get('counts', {})
        db_summary['queue'] = state.get('queue', {})
        # dedupe keys (truncadas)
        from bot.queue_store import load_queue
        queue, _ = load_queue()
        db_summary['queue_size'] = len(queue)
        db_summary['queue_approved'] = sum(1 for x in queue if x.get('status') == 'APPROVED')
        db_summary['queue_pending'] = sum(1 for x in queue if x.get('status') == 'PENDING')
        db_summary['dedupe_keys'] = [str(x.get('dedupe_key', ''))[:8] for x in queue[-5:]]
        # stats de histórico
        try:
            from state_store import get_stats
            db_summary['history_stats'] = get_stats('ALL', 'ow')
        except Exception:
            db_summary['history_stats'] = {}
    except Exception:
        pass
    with open(os.path.join(bundle_dir, 'db_summary.json'), 'w', encoding='utf-8') as f:
        f.write(sanitize_text(json.dumps(db_summary, indent=2, ensure_ascii=False)))
    # 5. Config/env sanitizado
    config_out = {}
    for k in ['HEADLESS', 'LOG_FILE', 'POLL_INTERVAL_SECONDS', 'CYCLE_MAX_SECONDS', 'QUEUE_MAX_SIZE', 'DEDUP_TTL_HOURS', 'MODERATION_ENABLED']:
        v = os.environ.get(k)
        if v is not None:
            config_out[k] = v
    # Mascara variáveis sensíveis
    for k in list(os.environ.keys()):
        if any(s in k for s in ['TOKEN', 'PASS', 'KEY', 'SECRET']):
            config_out[k] = '***'
    with open(os.path.join(bundle_dir, 'config_sanitized.json'), 'w', encoding='utf-8') as f:
        f.write(sanitize_text(json.dumps(config_out, indent=2, ensure_ascii=False)))
    # 6. Screenshots (opcional)
    if include_screenshots:
        ss_dir = os.path.join(bundle_dir, 'screenshots')
        os.makedirs(ss_dir, exist_ok=True)
        screenshots = sorted(glob.glob('screenshots/*.png'), reverse=True)[:3]
        for ss in screenshots:
            shutil.copy2(ss, os.path.join(ss_dir, os.path.basename(ss)))
    # 7. README.txt
    readme = f"""kiwi-bot debug bundle\ntimestamp: {ts}\nhostname: {socket.gethostname()}\nversao: (preencha git hash)\n\nInstruções: Anexe este ZIP ao chat para análise.\n\nArquivos:\n- logs/ (últimas 2000 linhas)\n- heartbeat.json\n- runtime_state.json\n- db_summary.json\n- config_sanitized.json\n- screenshots/ (se incluído)\n"""
    with open(os.path.join(bundle_dir, 'README.txt'), 'w', encoding='utf-8') as f:
        f.write(readme)
    # 8. ZIP
    zip_path = os.path.join(out_dir, f'kiwi_bot_debug_{ts}.zip')
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as z:
        for root, _, files in os.walk(bundle_dir):
            for file in files:
                abs_path = os.path.join(root, file)
                rel_path = os.path.relpath(abs_path, bundle_dir)
                z.write(abs_path, os.path.join('debug', rel_path))
    shutil.rmtree(bundle_dir)
    return zip_path
