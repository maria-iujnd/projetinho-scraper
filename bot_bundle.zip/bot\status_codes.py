from enum import Enum, auto
from dataclasses import dataclass, field
from typing import List, Optional, Dict

class ScrapeStatus(Enum):
    OK = auto()
    EMPTY = auto()
    BLOCKED = auto()
    ERROR = auto()

class ScrapeReason(Enum):
    NO_RESULTS = auto()
    COOKIE_MODAL_BLOCKING = auto()
    TIMEOUT_WAITING_RESULTS = auto()
    SELENIUM_EXCEPTION = auto()
    PAGE_NOT_LOADED = auto()
    UNKNOWN = auto()

@dataclass
class ScrapeResult:
    status: ScrapeStatus
    reason: ScrapeReason
    flights: List[dict] = field(default_factory=list)
    min_price: int = -1
    debug: Optional[Dict] = field(default_factory=dict)
