def format_date_br(iso_date: str) -> str:
    # TODO: migrar format_date_br do scrape_kiwi.py
    return iso_date
