"""
Decision Engine: centraliza regras de negócio, dedupe, prioridade, seleção de buckets/top N.
"""
from bot.selector import pick_best_3_buckets
from bot.prioritizer import compute_priority_score
from bot.message_builder import build_grouped_message
from bot.queue_store import is_in_queue
from bot.dedupe import make_offer_id, make_dedupe_key
import logging
from dataclasses import dataclass
from typing import Optional

@dataclass
class DecisionResult:
    should_enqueue: bool
    reason: str
    dedupe_key: Optional[str]
    priority: int
    message_text: Optional[str]

def evaluate_offer_batch(*, flights, min_price, ceiling, origin, dest, depart_date, queue, state_store):
    logger = logging.getLogger("kiwi_bot")
    if not flights:
        return DecisionResult(False, "NO_FLIGHTS", None, 0, None)
    if min_price is None or min_price <= 0:
        return DecisionResult(False, "NO_PRICE", None, 0, None)
    if min_price > ceiling:
        return DecisionResult(False, "ABOVE_CEILING", None, 0, None)
    best = pick_best_3_buckets(flights, ceiling)
    if not best:
        return DecisionResult(False, "NO_BEST_BUCKETS", None, 0, None)
    # ID forte
    offer = dict(best[0])
    offer["depart_date"] = depart_date
    route_key = f"{origin}-{dest}"
    trip_type = "RT_USA" if "EUA" in dest or "USA" in dest or "NYC" in dest else "OW"
    score, meta = compute_priority_score(
        price=min_price,
        ceiling=ceiling,
        route_key=route_key,
        trip_type=trip_type,
        state_store=state_store
    )
    priority = score
    offer_id = make_offer_id(offer)
    dedupe_key = make_dedupe_key(offer_id, channel="WHATSAPP", kind="ALERT")
    # Dedupe fila
    if is_in_queue(queue, dedupe_key):
        logger.info(f"[DEDUPE] skip reason=DUPLICATE_QUEUE key={dedupe_key}")
        return DecisionResult(False, "DUPLICATE_QUEUE", dedupe_key, priority, None)
    # Dedupe TTL
    DEDUP_TTL_HOURS = 24
    ttl_seconds = DEDUP_TTL_HOURS * 3600
    if hasattr(state_store, "was_seen_recently") and state_store.was_seen_recently(dedupe_key, ttl_seconds):
        logger.info(f"[DEDUPE] skip reason=DUPLICATE_TTL key={dedupe_key}")
        return DecisionResult(False, "DUPLICATE_TTL", dedupe_key, priority, None)
    logger.info(f"[PRIORITY] score={score} meta={meta}")
    # Grava sample para histórico
    if hasattr(state_store, "record_sample"):
        try:
            state_store.record_sample(route_key, trip_type, min_price)
        except Exception:
            pass
    message_text = build_grouped_message(
        origin,
        dest,
        depart_date,
        best,
        min_price,
        ceiling
    )
    return DecisionResult(True, "OK", dedupe_key, priority, message_text)
