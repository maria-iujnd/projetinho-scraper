
import time
import re
import traceback
from typing import List, Dict, Tuple
from bot.status_codes import ScrapeStatus, ScrapeReason, ScrapeResult
from bot.kiwi_cookies import try_accept_cookies, is_overlay_blocking
from bot.price_extractor import compute_min_price, find_price_for_sector

from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException

# Utilitário para aceitar cookies da Kiwi
def accept_kiwi_cookies(driver, wait, timeout=5):
    """
    Tenta aceitar cookies de forma idempotente e segura.
    Retorna True se aceitou, False se não havia modal ou não precisou.
    Nunca lança exception.
    """
    try:
        btn = None
        # Tenta por texto
        try:
            btn = wait.until(EC.element_to_be_clickable((
                By.XPATH,
                "//button[contains(., 'Aceit') or contains(., 'Accept')]"
            )), timeout=timeout)
        except Exception:
            pass
        # Tenta por data-test ou aria-label
        if not btn:
            try:
                btn = driver.find_element(By.XPATH, "//button[@data-test='CookieConsentButton']")
            except Exception:
                pass
        if not btn:
            try:
                btn = driver.find_element(By.XPATH, "//button[@aria-label='Aceitar cookies']")
            except Exception:
                pass
        if btn:
            try:
                btn.click()
                wait.until(EC.invisibility_of_element(btn))
                print("[COOKIES] accepted=True")
                return True
            except Exception:
                print("[COOKIES] accepted=False (click failed)")
                return False
        print("[COOKIES] accepted=False (not found)")
        return False
    except Exception:
        print("[COOKIES] accepted=False (exception)")
        return False

def is_overlay_blocking(driver) -> bool:
    # Detecta overlays comuns (position: fixed, z-index alto, modal visível)
    try:
        overlays = driver.find_elements(By.XPATH, "//*[contains(@style,'position: fixed') or contains(@style,'z-index')]")
        for el in overlays:

        if not flights:
                driver,
                wait: WebDriverWait,
                url: str,
                price_ceiling: int,
                max_results: int = 10,
            ) -> ScrapeResult:
                flights: List[Dict] = []
                min_price = None
                debug = {"url": url}
                try:
                    print(f"[SCRAPE] {url}")
                    driver.get(url)
                    # Aceita cookies (idempotente, seguro)
                    try_accept_cookies(driver, wait)
                    # Espera resultados ou erro
                    try:
                        wait.until(EC.presence_of_element_located((
                            By.XPATH,
                            '//*[@data-test="ResultCardSectorWrapper"] | //div[contains(text(),"Não conseguimos encontrar")]'
                        )), timeout=10)
                    except TimeoutException:
                        if is_overlay_blocking(driver):
                            try_accept_cookies(driver, wait)
                            if is_overlay_blocking(driver):
                                return ScrapeResult(
                                    status=ScrapeStatus.BLOCKED,
                                    reason=ScrapeReason.COOKIE_MODAL_BLOCKING,
                                    flights=[],
                                    min_price=-1,
                                    debug=debug
                                )
                        return ScrapeResult(
                            status=ScrapeStatus.EMPTY,
                            reason=ScrapeReason.TIMEOUT_WAITING_RESULTS,
                            flights=[],
                            min_price=-1,
                            debug=debug
                        )
                    if is_overlay_blocking(driver):
                        try_accept_cookies(driver, wait)
                        if is_overlay_blocking(driver):
                            return ScrapeResult(
                                status=ScrapeStatus.BLOCKED,
                                reason=ScrapeReason.COOKIE_MODAL_BLOCKING,
                                flights=[],
                                min_price=-1,
                                debug=debug
                            )
                    # Verifica mensagem de "no results"
                    if driver.find_elements(By.XPATH, '//div[contains(text(),"Não conseguimos encontrar")]'):
                        return ScrapeResult(
                            status=ScrapeStatus.EMPTY,
                            reason=ScrapeReason.NO_RESULTS,
                            flights=[],
                            min_price=-1,
                            debug=debug
                        )
                    sectors = driver.find_elements(By.CSS_SELECTOR, '[data-test="ResultCardSectorWrapper"]')
                    if not sectors:
                        return ScrapeResult(
                            status=ScrapeStatus.EMPTY,
                            reason=ScrapeReason.NO_RESULTS,
                            flights=[],
                            min_price=None,
                            debug=debug
                        )
                    # Preenche voos e preços robustamente
                    min_price, price_debug = compute_min_price(sectors[:max_results])
                    for sector in sectors[:max_results]:
                        try:
                            times = sector.find_elements(By.CSS_SELECTOR, '[data-test="TripTimestamp"] time')
                            hhmm = [t.text.strip() for t in times if re.match(r"^\d{1,2}:\d{2}$", (t.text or "").strip())]
                            dep_time = hhmm[0] if len(hhmm) > 0 else "?"
                            arr_time = hhmm[1] if len(hhmm) > 1 else "?"
                            try:
                                duration_text = sector.find_element(By.CSS_SELECTOR, '.orbit-badge-primitive time').text
                            except Exception:
                                duration_text = "?"
                            try:
                                airline = sector.find_element(By.CSS_SELECTOR, '[data-test="ResultCardCarrierLogo"] img').get_attribute("alt")
                            except Exception:
                                airline = "?"
                            try:
                                stations = sector.find_elements(By.CSS_SELECTOR, '[data-test="stationName"]')
                                origin_code = stations[0].text if len(stations) > 0 else "?"
                                dest_code = stations[1].text if len(stations) > 1 else "?"
                            except Exception:
                                origin_code = dest_code = "?"
                            try:
                                stops = sector.find_element(By.CSS_SELECTOR, 'p[data-test^="StopCountBadge"]').text
                            except Exception:
                                stops = "?"
                            # Preço robusto
                            price_int = find_price_for_sector(sector)
                            flights.append({
                                "price_int": price_int,
                                "dep_time": dep_time,
                                "arr_time": arr_time,
                                "duration_text": duration_text,
                                "origin_code": origin_code,
                                "dest_code": dest_code,
                                "stops": stops,
                                "airline": airline,
                            })
                        except Exception:
                            continue
                    debug["price_debug"] = price_debug
                    if not flights:
                        return ScrapeResult(
                            status=ScrapeStatus.EMPTY,
                            reason=ScrapeReason.NO_RESULTS,
                            flights=[],
                            min_price=min_price,
                            debug=debug
                        )
                    # Validação obrigatória: min_price não pode ser None
                    if min_price is None:
                        # Diagnóstico visual opcional: screenshot
                        try:
                            from datetime import datetime
                            import os
                            origin = debug.get("origin", "?")
                            dest = debug.get("dest", "?")
                            date = debug.get("date", datetime.now().strftime("%Y%m%d"))
                            fname = f"debug_price_fail_{origin}_{dest}_{date}.png"
                            driver.save_screenshot(fname)
                            debug["screenshot"] = os.path.abspath(fname)
                        except Exception as e:
                            debug["screenshot_error"] = str(e)
                        return ScrapeResult(
                            status=ScrapeStatus.ERROR,
                            reason=ScrapeReason.NO_PRICE_FOUND,
                            flights=flights,
                            min_price=None,
                            debug=debug
                        )
                    return ScrapeResult(
                        status=ScrapeStatus.OK,
                        reason=ScrapeReason.UNKNOWN,
                        flights=flights,
                        min_price=min_price,
                        debug=debug
                    )

                except Exception as e:
                    print("[SCRAPE][CRASH]", e)
                    traceback.print_exc()
                    return ScrapeResult(
                        status=ScrapeStatus.ERROR,
                        reason=ScrapeReason.SELENIUM_EXCEPTION,
                        flights=[],
                        min_price=None,
                        debug={"exception": str(e), "url": url}
                    )


