import hashlib
from typing import Dict

from bot.browser import open_browser, close_browser, warm_start
from bot.queue_store import load_queue, save_queue, enqueue_message, sort_queue, is_in_queue
from bot.message_builder import build_grouped_message
from bot.decision_engine import DecisionEngine
from bot.kiwi_scraper import scrape_with_selenium

try:
    from .. import routes_config as cfg
    from .. import state_store
except ImportError:
    import routes_config as cfg
    import state_store


def run(args) -> int:
    import time
    from bot.planner import plan_attempts
    from bot.reasons import AttemptReport
    from bot.reporting import print_summary, count_by_reason
    from bot.logging_setup import setup_logger
    logger = setup_logger()
    start_time = time.time()
    queue = load_queue(scope=args.scope)
    if len(queue) >= 20:
        logger.warning("[EXIT] fila cheia (queue size >= 20)")
        return 0
    driver = None
    reports = []
    counts_phase_reason = {}
    try:
        state_store.setup_database()
        logger.info(f"[START] headless={args.headless} scope={args.scope} origin={args.origin} dest={args.dest}")
        driver, wait = open_browser(
            headless=args.headless,
            scope=args.scope,
            kind="kiwi"
        )
        warm_start(driver)
        origin = args.origin
        dests = [args.dest] if args.dest else cfg.DAILY_DEST_IATA
        config = {
            'PRICE_CEILINGS_OW': cfg.PRICE_CEILINGS_OW,
            'DEFAULT_PRICE_CEILING_OW': cfg.DEFAULT_PRICE_CEILING_OW,
            'build_kiwi_url_ow': getattr(cfg, 'build_kiwi_url_ow', None),
            'date_window_days': getattr(cfg, 'DATE_WINDOW_DAYS', 7),
            'weekdays_only': getattr(cfg, 'WEEKDAYS_ONLY', False),
        }
        attempts, skip_reports = plan_attempts(origin=origin, dests=dests, config=config, state_store=state_store)
        reports.extend(skip_reports)
        for report in skip_reports:
            logger.info(f"[SKIP] {report.origin}->{report.dest} {report.date} {report.reason} {report.details}")
            key = (report.phase, report.reason)
            counts_phase_reason[key] = counts_phase_reason.get(key, 0) + 1
        for attempt in attempts:
            url = attempt['url']
            ceiling = attempt['ceiling']
            date = attempt['date']
            dest = attempt['dest']
            origin = attempt['origin']
            logger.info(f"[ATTEMPT] origin={origin} dest={dest} date={date} url={url}")
            scrape_result = scrape_with_selenium(driver, wait, url, ceiling)
            from bot.status_codes import ScrapeStatus
            if scrape_result.status != ScrapeStatus.OK or not scrape_result.flights:
                reports.append(AttemptReport(
                    origin=origin,
                    dest=dest,
                    date=date,
                    phase="SCRAPE",
                    reason=scrape_result.reason.name,
                    details=scrape_result.debug
                ))
                logger.warning(f"[SCRAPE] {origin}->{dest} {date} status={scrape_result.status.name} reason={scrape_result.reason.name} flights={len(scrape_result.flights)} min_price={scrape_result.min_price} url={url}")
                key = ("SCRAPE", scrape_result.reason.name)
                counts_phase_reason[key] = counts_phase_reason.get(key, 0) + 1
                continue
            # Decisão
            from bot.decision_engine import evaluate_offer_batch
            result = evaluate_offer_batch(
                flights=scrape_result.flights,
                min_price=scrape_result.min_price,
                ceiling=ceiling,
                origin=origin,
                dest=dest,
                depart_date=date,
                queue=queue,
                state_store=state_store
            )
            # Só tenta enrich_share_link se for enviar
            share_link, share_err = None, None
            if getattr(result, 'should_enqueue', False) and scrape_result.flights:
                try:
                    from bot.enrichment.share_link_enricher import enrich_share_link
                    share_link, share_err = enrich_share_link(driver, wait, card_index=0)
                    if share_link:
                        scrape_result.flights[0]["share_link"] = share_link
                    else:
                        logger.warning(f"[ENRICH] share_link_failed: {share_err} card_index=0")
                except Exception as e:
                    logger.error(f"[ENRICH][EXCEPTION] {e}")
            reports.append(AttemptReport(
                origin=origin,
                dest=dest,
                date=date,
                phase="DECISION",
                reason=getattr(result, 'reason', 'UNKNOWN'),
                details={}
            ))
            logger.info(f"[DECISION] {origin}->{dest} {date} reason={getattr(result, 'reason', 'UNKNOWN')} should_enqueue={getattr(result, 'should_enqueue', False)}")
            key = ("DECISION", getattr(result, 'reason', 'UNKNOWN'))
            counts_phase_reason[key] = counts_phase_reason.get(key, 0) + 1
            if getattr(result, 'should_enqueue', False):
                enqueue_message(
                    queue,
                    result.message_text,
                    result.dedupe_key,
                    result.priority
                )
                logger.info(f"[ENQUEUE] dedupe_key={result.dedupe_key} priority={result.priority} queue_size={len(queue)}")
                # Marca dedupe_key como seen (TTL dedupe)
                if hasattr(state_store, "mark_seen"):
                    state_store.mark_seen(result.dedupe_key)
        queue = sort_queue(queue)
        save_queue(queue, scope=args.scope)
        logger.info(f"[QUEUE] final size={len(queue)}")
        try:
            from bot.queue_models import queue_stats
            stats = queue_stats(queue)
            logger.info(f"[QUEUE] stats: total={stats['total']} approved={stats['approved']} pending={stats['pending']} sent={stats['sent']} dropped={stats['dropped']} top5={stats['top5_priorities']}")
        except Exception:
            stats = {}
        logger.info("[SUMMARY] Contadores por fase/motivo:")
        for (phase, reason), count in sorted(counts_phase_reason.items()):
            logger.info(f"  {phase}:{reason} = {count}")
        print_summary(reports)
        duration = time.time() - start_time
        logger.info(f"[END] Duração total: {duration:.1f}s")
        # Salva resumo do ciclo para status
        try:
            from bot.runtime_state import save_runtime_state
            save_runtime_state({
                "counts": {f"{phase}:{reason}": count for (phase, reason), count in counts_phase_reason.items()},
                "queue": stats,
                "duration": duration,
            })
        except Exception:
            pass
        return 0

    except Exception as e:
        logger.error(f"[CRASH] {type(e).__name__}: {e}")
        import traceback
        logger.error(traceback.format_exc())
        return 1

    finally:
        close_browser(driver)
