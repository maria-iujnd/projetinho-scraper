#!/usr/bin/env python3

import time
import json
import random
import os
import re
import argparse
import datetime
from date_utils import format_date_for_user  # Regra: toda data exibida ao usuário DEVE passar por esta função
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager

import state_store
import settings
# --- NOVOS CONTROLES ---
from bot.config import (
    SEND_TZ, SEND_WINDOWS, MAX_PER_HOUR_PER_GROUP, MIN_SECONDS_BETWEEN_MESSAGES_PER_GROUP
)
from bot.send_rate_control import can_send_group, can_send_route
import pytz
from datetime import datetime as dt

BASE_DIR = settings.BASE_DIR
QUEUE_FILE = settings.queue_file(None)
GROUP_NAME = settings.DEFAULT_GROUP_NAME

SEND_DELAY_MIN_SEC = settings.SEND_DELAY_MIN_SEC
SEND_DELAY_MAX_SEC = settings.SEND_DELAY_MAX_SEC
MAX_TO_SEND = settings.MAX_TO_SEND

# login persistente (evita QR toda vez)
CHROME_PROFILE_DIR = settings.whatsapp_profile_dir(None)
# --- Logger Simples ---
def log(level: str, msg: str) -> None:
    """Logger minimalista com timestamp e nível."""
    # Exemplo de uso da função centralizada para datas (caso precise exibir data para usuário)
    ts = datetime.datetime.now().strftime("%H:%M:%S")
    print(f"[{ts}] [{level}] {msg}")

# ATENÇÃO: NUNCA monte datas manualmente para o usuário!
# Sempre use format_date_for_user(dt) para exibir datas em mensagens, logs ou relatórios para o usuário final.

def sanitize_for_chromedriver(text: str) -> str:
    # Remove caracteres fora do BMP (U+0000..U+FFFF) que quebram send_keys
    return re.sub(r"[\U00010000-\U0010FFFF]", "", text)

def load_queue(path: str = QUEUE_FILE) -> list[dict]:
    """
    Load and normalize queue items to canonical schema.

    Canonical schema:
    {
      "id": "<string>",
      "text": "<string>",
      "priority": 0.0,
      "created_at": "ISO string",
      "group": "<string>"  # optional
    }
    """
    if not os.path.exists(path):
        return []
    try:
        with open(path, "r", encoding="utf-8") as f:
            raw = json.load(f)
    except (json.JSONDecodeError, OSError):
        print("[WARN] queue file missing or corrupt, returning empty queue")
        return []

    if not isinstance(raw, list):
        print("[WARN] queue JSON root is not a list, ignoring")
        return []

    normalized: list[dict] = []
    dropped = 0
    for item in raw:
        if not isinstance(item, dict):
            dropped += 1
            continue

        # Backward compatibility: 'message' -> 'text'
        if "text" not in item and "message" in item:
            item["text"] = item.get("message")

        mid = item.get("id")
        text = item.get("text")
        if not mid or not isinstance(mid, str):
            dropped += 1
            continue
        if not text or not isinstance(text, str) or text.strip() == "":
            dropped += 1
            continue

        priority = item.get("priority", 0.0)
        try:
            priority = float(priority)
        except Exception:
            priority = 0.0

        created_at = item.get("created_at")
        if not created_at or not isinstance(created_at, str):
            created_at = datetime.datetime.now().isoformat(timespec="seconds")

        normalized_item = {
            "id": str(mid),
            "text": text,
            "priority": float(priority),
            "created_at": created_at,
        }
        if "group" in item and item.get("group"):
            normalized_item["group"] = str(item.get("group"))

        normalized.append(normalized_item)

    if dropped:
        print(f"[WARN] dropped {dropped} invalid queue item(s)")

    return normalized

def save_queue(queue: list[dict], path: str = QUEUE_FILE) -> None:
    # Atomic write: write to temp and replace
    dirpath = os.path.dirname(path)
    if dirpath and not os.path.exists(dirpath):
        os.makedirs(dirpath, exist_ok=True)

    tmp_path = f"{path}.tmp"
    try:
        with open(tmp_path, "w", encoding="utf-8") as f:
            json.dump(queue, f, ensure_ascii=False, indent=2)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_path, path)
    except Exception as e:
        print(f"[ERROR] failed to save queue: {e}")
        try:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
        except Exception:
            pass

def open_whatsapp(driver: webdriver.Chrome) -> None:
    driver.get("https://web.whatsapp.com/")
    print("Abra o WhatsApp Web. Se pedir QR, escaneie com o celular.")
    wait = WebDriverWait(driver, 300)
    # Espera o painel lateral (elemento específico que indica login completo)
    wait.until(EC.presence_of_element_located((By.XPATH, "//div[@data-testid='pane-side']")))
    time.sleep(2)  # Aguarda renderização completa
    print("WhatsApp Web pronto.")

def open_chat_by_name(driver: webdriver.Chrome, chat_name: str) -> bool:
    """
    Localiza e abre um chat por nome.
    Retorna True se bem-sucedido, False caso contrário.
    """
    try:
        wait = WebDriverWait(driver, 30)

        # Localiza o campo de busca específico (input dentro do pane-side)
        search = wait.until(EC.presence_of_element_located((
            By.XPATH, 
            "//div[@data-testid='pane-side']//input[@aria-label or @placeholder]"
        )))
        search.click()
        time.sleep(0.5)
        
        # Limpa usando CTRL+A + DEL (melhor que .clear() para contenteditable)
        search.send_keys(Keys.CONTROL + "a")
        search.send_keys(Keys.DELETE)
        time.sleep(0.3)
        
        search.send_keys(chat_name)
        time.sleep(2)

        # Clica no chat resultado (mais específico)
        chat = wait.until(EC.element_to_be_clickable((
            By.XPATH, 
            f"//div[@data-testid='chat-list-item-container']//span[contains(text(), '{chat_name}')]"
        )))
        chat.click()
        time.sleep(1)
        return True
    
    except Exception as e:
        print(f"[WARN] Não foi possível abrir o chat '{chat_name}': {e}")
        return False

def send_message(driver: webdriver.Chrome, msg: str) -> bool:
    """
    Envia uma mensagem no chat atual.
    Retorna True se bem-sucedido, False caso contrário.
    """
    try:
        wait = WebDriverWait(driver, 30)
        
        # Localiza a caixa de texto do chat (footer com contenteditable)
        box = wait.until(EC.presence_of_element_located((
            By.XPATH,
            "//footer//div[@contenteditable='true'][@data-tab='1']"
        )))
        box.click()
        time.sleep(0.2)

        safe_msg = sanitize_for_chromedriver(msg)

        # Envia linha por linha usando SHIFT+ENTER para quebras
        actions = ActionChains(driver)
        lines = safe_msg.splitlines()

        for i, l in enumerate(lines):
            if l:
                actions.send_keys(l)
            if i < len(lines) - 1:
                actions.key_down(Keys.SHIFT).send_keys(Keys.ENTER).key_up(Keys.SHIFT)
                time.sleep(0.1)

        actions.perform()
        time.sleep(0.3)
        
        # Envia APENAS via botão (não duplica com ENTER)
        send_btn = wait.until(EC.element_to_be_clickable((
            By.XPATH, 
            "//footer//button[@aria-label='Enviar' or @aria-label='Send']"
        )))
        send_btn.click()
        time.sleep(0.5)
        return True
    
    except Exception as exc:
        print(f"[ERROR] Falha ao enviar mensagem: {exc}")
        return False

def is_within_send_window():
    tz = pytz.timezone(SEND_TZ)
    now = dt.now(tz)
    # Suporta múltiplas janelas no formato "08:00-09:00,11:00-12:00"
    for window in SEND_WINDOWS.split(","):
        start_str, end_str = window.split("-")
        start = dt.strptime(start_str, "%H:%M").replace(year=now.year, month=now.month, day=now.day, tzinfo=tz)
        end = dt.strptime(end_str, "%H:%M").replace(year=now.year, month=now.month, day=now.day, tzinfo=tz)
        if end <= start:
            end += datetime.timedelta(days=1)
        if start <= now <= end:
            return True
    return False

def get_tier(score):
    MIN_SCORE_TO_SEND = 200  # Valor padrão local, ajuste conforme necessário
    if score >= 400:
        return "HOT"
    elif score >= 300:
        return "GOOD"
    elif score >= MIN_SCORE_TO_SEND:
        return "INFO"
    return "LOW"

def main():

    # --- INICIALIZAÇÃO DE VARIÁVEIS NO TOPO DO MAIN ---
    parser = argparse.ArgumentParser()
    parser.add_argument('--dry-run', action='store_true', help='Não envia, só simula')
    parser.add_argument('--scope', type=str, default=None, help='Escopo do banco')
    args = parser.parse_args()

    queue_file = QUEUE_FILE
    queue = load_queue(queue_file)
    driver = None
    run_id = f"run_{int(time.time())}"
    initial_queued = len(queue)

    # Agrupa mensagens por grupo
    messages_by_group = {}
    for item in queue:
        group = item.get("group") or GROUP_NAME
        messages_by_group.setdefault(group, []).append(item)

    try:
        if not args.dry_run:
            # Inicializa o driver apenas se não for dry-run
            options = webdriver.ChromeOptions()
            options.add_argument(f"--user-data-dir={CHROME_PROFILE_DIR}")
            driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)
            open_whatsapp(driver)

        total_sent = 0
        group_stats = {}

        for group, items in messages_by_group.items():
            if total_sent >= MAX_TO_SEND:
                log("INFO", f"Limite de {MAX_TO_SEND} mensagens atingido. Encerrando.")
                break

            log("INFO", f"Processando grupo: '{group}' ({len(items)} itens)")
            group_stats[group] = {"tentadas": len(items), "enviadas": 0, "erro": False}

            if driver and not args.dry_run:
                success = open_chat_by_name(driver, group)
                if not success:
                    log("WARN", f"Grupo '{group}' não encontrado. Pulando.")
                    group_stats[group]["erro"] = True
                    continue

            print(f"\nEnviando para o grupo '{group}'...")

            sent_in_group = 0
            i = 0
            while i < len(items):
                if total_sent >= MAX_TO_SEND:
                    print(f"[LIMIT] Limite de {MAX_TO_SEND} mensagens atingido.")
                    break

                item = items[i]
                msg = item.get("message") or item.get("text") or ""

                if not msg.strip():
                    print(f"[WARN] Item ignorado (sem 'text' ou vazio). ID: {item.get('id', '?')}")
                    items.pop(i)
                    queue.remove(item)
                    if not args.dry_run:
                        save_queue(queue, queue_file)
                    continue

                allowed, reason = can_send_now(group)
                if not allowed:
                    if reason.startswith("GROUP_SPACING"):
                        log("SEND", f"blocked reason=GROUP_SPACING group={group} {reason}")
                    elif reason == "OUTSIDE_WINDOW":
                        log("SEND", f"blocked reason=OUTSIDE_WINDOW group={group}")
                    elif reason == "GROUP_HOURLY_LIMIT":
                        sent_last_hour = len(state_store.get_group_send_timestamps(group, window_seconds=3600))
                        log("SEND", f"blocked reason=GROUP_HOURLY_LIMIT group={group} sent_last_hour={sent_last_hour}")
                    else:
                        log("SEND", f"blocked reason={reason} group={group}")
                    break

                if args.dry_run:
                    print(f"[DRY-RUN] Para '{group}':\n{msg}\n" + "-"*20)
                    sent_in_group += 1
                    total_sent += 1
                    i += 1
                    continue

                # Envia a mensagem
                success = send_message(driver, msg)
                if not success:
                    log("WARN", f"Falha ao enviar para '{group}'.")
                    i += 1
                    continue

                offer_hash = item.get("id") or item.get("offer_hash")
                if offer_hash:
                    state_store.mark_announced(offer_hash)

                state_store.record_group_send(group)

                sent_in_group += 1
                total_sent += 1
                group_stats[group]["enviadas"] = sent_in_group

                items.pop(i)
                queue.remove(item)
                save_queue(queue, queue_file)

                pr = float(item.get("priority", 0.0) or 0.0)
                delay = random.randint(SEND_DELAY_MIN_SEC, SEND_DELAY_MAX_SEC)

                print(f"[{sent_in_group}] enviada para '{group}'. Próxima em {delay}s.")
                time.sleep(delay)

            log("INFO", f"Grupo '{group}': {sent_in_group}/{len(items)} enviadas")
    except Exception as e:
        log("ERROR", f"Exceção: {e}")
        import traceback
        traceback.print_exc()
        try:
            state_store.run_log_finish(run_id, "FAIL", checked_items=0, queued=initial_queued, sent=total_sent if 'total_sent' in locals() else 0, errors=str(e)[:4096], db_path=settings.db_file(args.scope or None))
        except Exception:
            pass
    finally:
        if not args.dry_run:
            save_queue(queue, queue_file)
        if driver:
            driver.quit()



if __name__ == "__main__":
    main()