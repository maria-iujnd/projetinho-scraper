import hashlib
import json
from typing import Dict

def make_offer_id(offer: Dict) -> str:
    """
    Gera um ID forte e estável para o voo/oferta.
    Prioridade: share_link (hash curto), senão fingerprint dos campos estáveis.
    """
    share_link = offer.get("share_link")
    if share_link and isinstance(share_link, str) and share_link.startswith("http"):
        h = hashlib.sha1(share_link.encode()).hexdigest()[:12]
        return f"S_{h}"
    # Fallback: fingerprint
    fields = [
        offer.get("origin_code"),
        offer.get("dest_code"),
        offer.get("dep_time"),
        offer.get("airline"),
        offer.get("duration_text"),
        offer.get("stops"),
        offer.get("depart_date"),
    ]
    fingerprint = ":".join([str(f) for f in fields if f is not None])
    h = hashlib.sha1(fingerprint.encode()).hexdigest()[:12]
    return f"F_{h}"

def make_dedupe_key(offer_id: str, *, channel: str, kind: str) -> str:
    """
    Monta dedupe_key: KIND|CHANNEL|<offer_id>
    """
    return f"{kind}|{channel}|{offer_id}"
