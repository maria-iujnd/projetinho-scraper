import re
from typing import Optional, List, Tuple, Dict

def extract_price_int_from_text(text: str) -> Optional[int]:
    """
    Extrai um inteiro de preço de textos como 'R$ 1.234', '1.234', 'BRL 1,234', etc.
    Retorna None se não encontrar.
    """
    if not text:
        return None
    # Remove currency symbols and letters
    cleaned = re.sub(r'[^0-9.,]', '', text)
    # Troca vírgula por ponto se for separador decimal
    if cleaned.count(',') == 1 and cleaned.count('.') == 0:
        cleaned = cleaned.replace(',', '.')
    # Remove milhares
    cleaned = cleaned.replace('.', '').replace(',', '')
    try:
        value = int(cleaned)
        return value if value > 0 else None
    except Exception:
        return None

def find_price_for_sector(sector_element) -> Optional[int]:
    """
    Tenta extrair o preço de um sector/card, subindo para containers pais e siblings se necessário.
    sector_element: Selenium WebElement
    """
    # 1. Tenta dentro do próprio sector
    price_selectors = [
        '[data-test-id="price"]',
        '.price',
        '.amount',
        '[class*="Price"]',
    ]
    for sel in price_selectors:
        try:
            el = sector_element.find_element('css selector', sel)
            price = extract_price_int_from_text(el.text)
            if price:
                return price
        except Exception:
            continue
    # 2. Sobe para o card pai
    try:
        parent = sector_element.find_element('xpath', './ancestor::*[contains(@class,"card")]')
        for sel in price_selectors:
            try:
                el = parent.find_element('css selector', sel)
                price = extract_price_int_from_text(el.text)
                if price:
                    return price
            except Exception:
                continue
    except Exception:
        pass
    # 3. Siblings/containers próximos
    try:
        sibling = sector_element.find_element('xpath', 'following-sibling::*')
        for sel in price_selectors:
            try:
                el = sibling.find_element('css selector', sel)
                price = extract_price_int_from_text(el.text)
                if price:
                    return price
            except Exception:
                continue
    except Exception:
        pass
    # 4. Falhou
    return None

def compute_min_price(flight_sectors: List) -> Tuple[Optional[int], Dict]:
    """
    Itera setores, chama find_price_for_sector, coleta preços e debug.
    Retorna (min_price, debug_dict)
    """
    prices_found = []
    debug_samples = []
    missing_count = 0
    for sector in flight_sectors:
        price = find_price_for_sector(sector)
        if price is not None:
            prices_found.append(price)
            if len(debug_samples) < 3:
                try:
                    debug_samples.append(sector.text)
                except Exception:
                    debug_samples.append('NO_TEXT')
        else:
            missing_count += 1
    min_price = min(prices_found) if prices_found else None
    debug = {
        'prices_found': prices_found,
        'missing_count': missing_count,
        'debug_samples': debug_samples,
        'sectors_count': len(flight_sectors),
    }
    return min_price, debug
