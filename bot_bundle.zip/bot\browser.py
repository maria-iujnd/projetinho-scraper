import os
import sys
import time
import platform
import tempfile
import random
from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.common.exceptions import WebDriverException, InvalidSessionIdException

class BrowserManager:
    def __init__(self, headless=False, scope="", kind="kiwi", wait_seconds=20, config=None):
        self.headless = headless
        self.scope = scope
        self.kind = kind
        self.wait_seconds = wait_seconds
        self.config = config or {}
        self.driver = None
        self.wait = None
        self.profile_dir = None
        self._start_new_driver()

    @staticmethod
    def get_profile_base_dir():
        if sys.platform.startswith("win"):
            localappdata = os.environ.get("LOCALAPPDATA")
            if localappdata:
                return os.path.join(localappdata, "kiwi_bot_profiles")
        elif sys.platform == "darwin":
            return os.path.expanduser("~/Library/Application Support/kiwi_bot_profiles")
        # Linux e outros
        return os.path.expanduser("~/.config/kiwi_bot_profiles")

    @staticmethod
    def build_chrome_options(headless=False, profile_dir=None, config=None):
        options = webdriver.ChromeOptions()
        options.add_argument("--no-sandbox")
        options.add_argument("--disable-dev-shm-usage")
        options.add_argument("--disable-gpu")
        options.add_argument("--window-size=1280,900")
        options.add_argument("--lang=pt-BR")
        options.add_argument("--disable-notifications")
        if profile_dir:
            options.add_argument(f"--user-data-dir={profile_dir}")
            options.add_argument("--profile-directory=Default")
        if headless or (config and config.get("HEADLESS")):
            options.add_argument("--headless=new")
        return options

    def _unique_profile_dir(self):
        base = self.get_profile_base_dir()
        os.makedirs(base, exist_ok=True)
        pid = os.getpid()
        ts = int(time.time())
        rand = random.randint(1000, 9999)
        name = f"profile_{self.kind}_{self.scope}_pid{pid}_{ts}_{rand}"
        profile_dir = os.path.join(base, name)
        os.makedirs(profile_dir, exist_ok=True)
        return profile_dir

    def _start_new_driver(self):
        self.profile_dir = self._unique_profile_dir()
        options = self.build_chrome_options(self.headless, self.profile_dir, self.config)
        print(f"[BROWSER] start profile={self.profile_dir} headless={self.headless} pid={os.getpid()}")
        self.driver = webdriver.Chrome(options=options)
        self.wait = WebDriverWait(self.driver, self.wait_seconds)

    def start(self):
        if not self.driver:
            self._start_new_driver()
        return self.driver, self.wait

    def stop(self):
        if self.driver:
            try:
                self.driver.quit()
            except Exception:
                pass
            self.driver = None
            self.wait = None

    def is_alive(self):
        try:
            _ = self.driver.title
            return True
        except (WebDriverException, InvalidSessionIdException):
            return False
        except Exception:
            return False

    def restart(self):
        print("[BROWSER] restart reason=manual or detected dead session")
        try:
            from bot.notify import notify_admin
            notify_admin("BROWSER_RESTART", f"Browser reiniciado em {time.strftime('%Y-%m-%d %H:%M:%S')}", alert_type="BROWSER_RESTART")
        except Exception:
            pass
        self.stop()
        self._start_new_driver()
        return self.driver, self.wait

    def safe_get(self, url, max_attempts=3):
        for attempt in range(1, max_attempts+1):
            try:
                self.driver.get(url)
                return True
            except (WebDriverException, InvalidSessionIdException) as e:
                print(f"[BROWSER] get failed url={url} attempt={attempt} reason={type(e).__name__}: {e}")
                self.restart()
            except Exception as e:
                print(f"[BROWSER] get failed url={url} attempt={attempt} reason={type(e).__name__}: {e}")
                self.restart()
        return False


def close_browser(driver):
    """Fecha o Chrome com segurança."""
    if not driver:
        return
    try:
        driver.quit()
    except Exception:
        pass
    try:
        driver.quit()
    except Exception:
        pass

def warm_start(driver: webdriver.Chrome, url: str = "https://www.kiwi.com/br/", seconds: float = 2.0) -> None:
    """Aquece sessão (carrega home pra reduzir flutuações)."""
    driver.get(url)
    time.sleep(seconds)
