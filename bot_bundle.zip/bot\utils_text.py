def parse_brl_to_int(price_text: str) -> int:
    # TODO: migrar parse_brl_to_int do scrape_kiwi.py
    return -1

def brl(valor: int) -> str:
    # TODO: migrar brl do scrape_kiwi.py
    return str(valor)
